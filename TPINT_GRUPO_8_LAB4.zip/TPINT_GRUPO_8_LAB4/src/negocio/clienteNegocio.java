package negocio;

public interface clienteNegocio {
	
}
