package negocioImpl;

public class clienteNegocioImpl {

}
